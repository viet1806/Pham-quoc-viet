﻿using BaiTH.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BaiTH.Controllers
{
    public class ExamController : Controller
    {
        private readonly DatabaseContext _context;

        public ExamController(DatabaseContext context)
        {
            _context = context;
        }
        // GET: ExamController
        public ActionResult Index()
        {
            return View(_context.Exams.ToList());
        }

        // GET: ExamController/Details/5
        public ActionResult Details(int id)
        {
            return View(_context.Exams.Find(id));
        }

        // GET: ExamController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ExamController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Exam model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Exams.Add(model);
                    var result = _context.SaveChanges();
                    if (result > 0)
                    {
                        return RedirectToAction(nameof(Index));
                    }
                    else return View(model);
                }
                return View(model);
            }
            catch
            {
                return View();
            }
        }

        // GET: ExamController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ExamController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                var update = _context.Exams.Find(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ExamController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ExamController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
