﻿using Microsoft.EntityFrameworkCore;

namespace BaiTH.Models
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Exam> Exams { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>().HasData(new Student()
            {
                StudentId = 1,
                Name = "Ndt",
                DateOfBirth = "12/02/2003",
                Email = "toannd23@gmail.com",
                Address = "HN"
            });
            modelBuilder.Entity<Student>().HasData(new Student()
            {
                StudentId = 2,
                Name = "Bpm",
                DateOfBirth = "07/02/2003",
                Email = "mei02@gmail.com",
                Address = "HN"
            });
            modelBuilder.Entity<Student>().HasData(new Student()
            {
                StudentId = 3,
                Name = "Ndta",
                DateOfBirth = "12/15/2003",
                Email = "tuanh@gmail.com",
                Address = "HD"
            });
            modelBuilder.Entity<Subject>().HasData(new Subject()
            {
                SubjectId = 1,
                SubjectName = "Cấu trúc dữ liệu và giải thuật",
                SubjectCode = "IT1",
                Description = "",
                StartDate = "02/06/2023",
                EndDate = "02/06/2024"
            });
            modelBuilder.Entity<Subject>().HasData(new Subject()
            {
                SubjectId = 2,
                SubjectName = "Lập trình hướng đối tượng",
                SubjectCode = "IT2",
                Description = "",
                StartDate = "02/06/2023",
                EndDate = "02/06/2024"
            });
            modelBuilder.Entity<Subject>().HasData(new Subject()
            {
                SubjectId = 3,
                SubjectName = "Cơ sở dữ liệu",
                SubjectCode = "IT3",
                Description = "",
                StartDate = "02/06/2023",
                EndDate = "02/06/2024"
            });
        }
    }
}
