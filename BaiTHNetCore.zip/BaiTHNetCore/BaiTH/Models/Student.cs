﻿using System.ComponentModel.DataAnnotations;

namespace BaiTH.Models
{
    public class Student
    {
        public long StudentId { get; set; }
        public string Name { get; set; }
        public string? DateOfBirth { get; set; }
        public string Email { get; set; }
        [Required]
        public string Address { get; set; }

        public virtual List<Exam>? Exams { get; set; }
    }
}
