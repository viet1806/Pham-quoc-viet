﻿using System.ComponentModel.DataAnnotations;

namespace BaiTH.Models
{
    public class Subject
    {
        public int SubjectId { get; set; }

        [StringLength(150, MinimumLength =8)]
        public string SubjectName { get; set; }

        [StringLength(150, MinimumLength = 2)]
        public string SubjectCode { get; set; }

        [StringLength(500)]
        public string? Description { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }

        public virtual List<Exam>? Exams { get; set; }
    }
}
